<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class Paypal_Adaptive_Payment extends WC_Payment_Gateway
{
    public $api_user;
    public $api_pass;
    public $api_sig;
    public $app_id;
    public $apiUrl;
    public $paypalUrl="https://www.paypal.com/webscr?cmd=_ap-payment&paykey=";
    public $sandboxPaypalUrl = 'https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_ap-payment&paykey=';
    public $headers;

    protected static $_instance = null;

    /**
     * @return null|Wpneo_Crowdfunding
     */
    public static function instance() {
        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct(){
        $this->id = 'paypal_adaptive_payment';
        $this->has_fields = false;
        $this->method_title = 'PayPal Adaptive Payment';

        $this->init_form_fields();
        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );

        // Get settings
        $this->api_user = $this->get_option('api_user_id');
        $this->api_pass = $this->get_option('api_password');
        $this->api_sig = $this->get_option('api_signature');
        $this->app_id = $this->get_option('application_id');

        //Setting api URL
        if ($this->get_option('sandbox') == 'yes') {
            $this->apiUrl = 'https://svcs.sandbox.paypal.com/AdaptivePayments/';
        }else{
            $this->apiUrl = 'https://svcs.paypal.com/AdaptivePayments/';
        }

        $this->title              = $this->get_option('title');
        $this->description        = $this->get_option( 'description' );
        $this->instructions       = $this->get_option( 'instructions');

        //Set headers settings
        $this->headers = array(
            "X-PAYPAL-SECURITY-USERID: ".$this->api_user,
            "X-PAYPAL-SECURITY-PASSWORD: ".$this->api_pass,
            "X-PAYPAL-SECURITY-SIGNATURE: ".$this->api_sig,
            "X-PAYPAL-REQUEST-DATA-FORMAT: JSON",
            "X-PAYPAL-RESPONSE-DATA-FORMAT: JSON",
            "X-PAYPAL-APPLICATION-ID: ".$this->app_id,
        );
    }

    /**
     * @param $data
     * @param $call
     * @return array|mixed|object
     *
     * @_paypalSend() for post to paypal with CURL
     */

    public function _paypalSend($data,$call){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $this->apiUrl.$call);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);
        $response = json_decode(curl_exec($ch),true);
        return $response;
    }

    /**
     * @param $order_id
     * @return array|mixed|object
     *
     * @splitPay() parameter and decide its parallel or chained
     */
    public function splitPay($order_id){
        $order = new WC_Order($order_id);
        $success_url = $this->get_return_url($order);
        $cancel_url = str_replace("&amp;", "&", $order->get_cancel_order_url());
        $ipn_notification_url = esc_url_raw(add_query_arg(array('ipn' => 'set', 'self_custom' => $order_id), site_url('/')));

        // create the pay request
        $createPacket = array(
            "actionType" =>"PAY",
            "currencyCode" => get_woocommerce_currency(),
            "receiverList" => array(),
            "returnUrl" => $success_url,
            "cancelUrl" => $cancel_url,
            'ipnNotificationUrl' => $ipn_notification_url,
            "requestEnvelope" => array(
                "errorLanguage" => "en_US",
                "detailLevel" => "ReturnAll",
            ),
        );

        $post_camaigner_paypal_id = '';
        $receiver_one_email = $this->get_option('paypal_email');
        $receiver_one_percent = $this->get_option('percent');

        //Get total ordered amount from order item
        $total_amount = 0;
        foreach ($order->get_items() as $item) {
            $total_amount = $order->get_line_total($item) + $total_amount;

            $product = wc_get_product($item['product_id']);
            if($product->get_type() == 'crowdfunding'){
                //v.1.3
                $product_as_post = get_post($item['product_id']);
                $adaptive_paypal_receiver_email = get_user_meta($product_as_post->post_author, 'adaptive_paypal_receiver_email', true);

                //$post_camaigner_paypal_id = get_post_meta($item['product_id'], "wpneo_campaigner_paypal_id", true);
                $post_camaigner_paypal_id = $adaptive_paypal_receiver_email;
            }
        }

        $receiver_one_share = ($total_amount * $receiver_one_percent) / 100;

        $receiver_two_share = 0;
        $receiver_two_email = $this->get_option('second_paypal_email');
        if ($this->get_option('second_paypal_receiver') == 'yes'){
            $receiver_two_percent = $this->get_option('second_percent');
            $receiver_two_share = ($total_amount * $receiver_two_percent) / 100;
        }
        $campaign_creator_share = $total_amount - ($receiver_one_share + $receiver_two_share);

        if ($this->get_option('payment_mode') == 'parallel'){
            $createPacket['receiverList'] = array(
                "receiver" => array(
                    array(
                        "amount"    => $campaign_creator_share,
                        "email"     => $post_camaigner_paypal_id
                    ),
                    array(
                        "amount"    => $receiver_one_share,
                        "email"     => $receiver_one_email
                    ),
                ),
            );

            if ($receiver_two_share > 0){
                $createPacket['receiverList']['receiver'][] = array(
                    "amount"    => $receiver_two_share,
                    "email"     => $receiver_two_email
                );
            }
        }elseif ($this->get_option('payment_mode') == 'chained'){
            $createPacket['receiverList'] = array(
                "receiver" => array(
                    array(
                        "amount"    => $receiver_one_share,
                        "email"     => $receiver_one_email,
                        "primary"   => "true"
                    ),
                    array(
                        "amount"    => $campaign_creator_share,
                        "email"     => $post_camaigner_paypal_id,
                        "primary"   => "false"
                    ),
                ),
            );

            if ($receiver_two_share > 0){
                $createPacket['receiverList']['receiver'][] = array(
                    "amount"    => $receiver_two_share,
                    "email"     => $receiver_two_email,
                    "primary"   => "false"
                );
            }

        }

        $response = $this->_paypalSend($createPacket,"Pay");
        //die(print_r($response,true));
        return $response;
    }

    /**
     * Initialise Gateway Settings Form Fields.
     */
    public function init_form_fields() {

        $this->form_fields = array(
            'enabled' => array(
                'title'       => __( 'Enable PayPal Adaptive Payment', 'wp-crowdfunding' ),
                'label'       => __( 'Enable PayPal Adaptive Payment', 'wp-crowdfunding' ),
                'type'        => 'checkbox',
                'description' => '',
                'default'     => 'no'
            ),

            'sandbox' => array(
                'title' 		=> __( 'Enable/Disable', 'wp-crowdfunding' ),
                'type' 			=> 'checkbox',
                'label' 		=> __( 'Enable PayPal Sanbox Mode', 'wp-crowdfunding' ),
                'default' 		=> 'no'
            ),

            'paypal_email' => array(
                'title' 		=> __( 'Paypal Payment Receiver Email', 'wp-crowdfunding' ),
                'type' 			=> 'text',
                'desc_tip' 		=> true,
                'description' 	=> __( 'Put your PayPal account here.', 'wp-crowdfunding' ),
                'default' 		=> ''
            ),

            'percent' => array(
                'title' 		=> __( 'Receiver\'s Percentage', 'wp-crowdfunding' ),
                'type' 			=> 'text',
                'desc_tip' 		=> true,
                'description' 	=> __( 'Put the percentage of the money here.', 'wp-crowdfunding' ),
                'default' 		=> ''
            ),

            'second_paypal_receiver' => array(
                'title' 		=> __( 'Enable/Disable', 'wp-crowdfunding' ),
                'type' 			=> 'checkbox',
                'label' 		=> __( 'Enable PayPal Second receiver', 'wp-crowdfunding' ),
                'default' 		=> 'no'
            ),
            'second_paypal_email' => array(
                'title' 		=> __( 'Second Receiver PayPal Email', 'wp-crowdfunding' ),
                'type' 			=> 'text',
                'desc_tip' 		=> true,
                'description' 	=> __( 'Put your second receiver PayPal account here.', 'wp-crowdfunding' ),
                'default' 		=> ''
            ),

            'second_percent' => array(
                'title' 		=> __( 'Second Receiver\'s Percentage', 'wp-crowdfunding' ),
                'type' 			=> 'text',
                'desc_tip' 		=> true,
                'description' 	=> __( 'Put the Second Receiver\'s percentage of the money here.', 'wp-crowdfunding' ),
                'default' 		=> ''
            ),

            'payment_mode' => array(
                'title' 		=> __( 'Payment Mode', 'wp-crowdfunding' ),
                'type' 			=> 'select',
                'label' 		=> __( 'Select paypal payment mode', 'wp-crowdfunding' ),
                'default' 		=> 'parallel',
                'options'       => array(
                    'parallel'=>'parallel',
                    'chained'=>'chained'
                ),
                'desc_tip'      => true
            ),
            'api_user_id' => array(
                'title' 		=> __( 'API User ID', 'wp-crowdfunding' ),
                'type' 			=> 'text',
                'desc_tip' 		=> true,
                'description' 	=> __( 'Put your PayPal API user ID here', 'wp-crowdfunding' ),
                'default' 		=> ''
            ),
            'api_password' => array(
                'title' 		=> __( 'API Password', 'wp-crowdfunding' ),
                'type' 			=> 'text',
                'desc_tip' 		=> true,
                'description' 	=> __( 'Put your PayPal API Password here', 'wp-crowdfunding' ),
                'default' 		=> ''
            ),
            'api_signature' => array(
                'title' 		=> __( 'API Signature', 'wp-crowdfunding' ),
                'type' 			=> 'text',
                'desc_tip' 		=> true,
                'description' 	=> __( 'Put your payPal API signature here', 'wp-crowdfunding' ),
                'default' 		=> ''
            ),
            'application_id' => array(
                'title' 		=> __( 'Application ID', 'wp-crowdfunding' ),
                'type' 			=> 'text',
                'desc_tip' 		=> true,
                'description' 	=> __( 'Put your paypal application ID here', 'wp-crowdfunding' ),
                'default' 		=> ''
            ),
            'title' => array(
                'title' 		=> __( 'Title', 'wp-crowdfunding' ),
                'type' 			=> 'text',
                'description' 	=> __( 'This controls the title which the user sees during checkout.', 'wp-crowdfunding' ),
                'desc_tip' 		=> true,
                'default' 		=> __( 'Paypal Adaptive Payment', 'wp-crowdfunding' )
            ),
            'description' => array(
                'title' 		=> __( 'Description', 'wp-crowdfunding' ),
                'type' 			=> 'textarea',
                'desc_tip' 		=> true,
                'description' 	=> __( 'This controls the description which the user sees during checkout.', 'wp-crowdfunding' ),
                'default' 		=> __( 'Desctiptions of Payment Gateways.', 'wp-crowdfunding' )
            ),
            'instructions' => array(
                'title' 		=> __( 'Instructions', 'wp-crowdfunding' ),
                'type' 			=> 'textarea',
                'desc_tip' 		=> true,
                'description' 	=> __( 'Instructions that will be added to the thank you page.', 'wp-crowdfunding' ),
                'default' 		=> __( 'Instructions for Payment Gateways.', 'wp-crowdfunding' )
            ),

        );
    }

    public function process_payment( $order_id ) {
        $order          = wc_get_order( $order_id );
        $redirect_wp = $this->splitPay($order_id);
        //die(print_r($redirect_wp, true));
        $ap_key = $redirect_wp['payKey'];

        if ($this->get_option('sandbox') == 'yes') {
            $redirect_url = $this->sandboxPaypalUrl . $ap_key;
        }else{
            $redirect_url = $this->paypalUrl . $ap_key;
        }

        //die(print_r($redirect_wp, true));
        return array(
            'result'   => 'success',
            'redirect' => $redirect_url
        );
    }
}

//Paypal_Adaptive_Payment::instance();

function add_paypal_adaptive_payment( $methods ) {
    $methods[] = 'Paypal_Adaptive_Payment';
    return $methods;
}
add_filter( 'woocommerce_payment_gateways', 'add_paypal_adaptive_payment' );