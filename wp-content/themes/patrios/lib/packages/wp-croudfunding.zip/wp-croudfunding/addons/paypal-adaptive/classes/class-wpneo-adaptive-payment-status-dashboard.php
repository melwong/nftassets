<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if (! class_exists('WPNEO_Adaptive_Payment_Status_Dashboard')) {

    class WPNEO_Adaptive_Payment_Status_Dashboard
    {

        protected static $_instance;

        public static function instance()
        {
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        public function __construct()
        {
            add_action( 'wp_dashboard_setup', array( $this, 'init' ) );
        }

        public function init(){
            wp_add_dashboard_widget('wpneo_crowdfunding_paypal_adaptive_payment_status', __('WPNEO PayPal Adaptive Payment System Status', 'wp-crowdfunding'),
                array($this, 'wpneo_crowdfunding_paypal_adaptive_payment_status'));
        }

        /**
         * Get this info to wordpress dashboard
         */

        public function wpneo_crowdfunding_paypal_adaptive_payment_status(){
            global $wp_version, $woocommerce;
            $wc_version = $woocommerce->version;
            $tls_version = 0;

            $red_text = ' style="color:#ff0000" ';
            $green_text = ' style="color:#32CD32" ';

            $ch = curl_init('https://www.howsmyssl.com/a/check');
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_NTLM);

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $data = curl_exec($ch);
            curl_close($ch);

            $json = json_decode($data);
            if ( ! empty($json->tls_version)) {
                $tls_version = (float)filter_var($json->tls_version, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            }

            $http_version = (float) filter_var( $_SERVER['SERVER_PROTOCOL'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION );

            $crowdfunding_version  = '<span '.$green_text.'>WP Crowdfunding Version '.WPNEO_CROWDFUNDING_VERSION.' ('
                                     .ucfirst(WPNEO_CROWDFUNDING_TYPE).') </span>';

            if (version_compare(PHP_VERSION, '5.3.0', '>=')) {
                $php_version_status = '<span '.$green_text.'>PHP version : '.PHP_VERSION.' (OK)</span>';
            }else{
                $php_version_status = '<span '.$red_text.'>You need min PHP version : 5.3.0 (ERROR)</span>';
            }

            if (version_compare($wp_version, '4.4.3', '>=')) {
                $wp_version_status = '<span '.$green_text.'>Wordpress version : '.$wp_version.' (OK)</span>';
            }else{
                $wp_version_status = '<span '.$red_text.'>Min recommended wordpress version : 4.4.3 (ERROR)</span>';
            }

            if (version_compare($wc_version, '2.5', '>=')) {
                $wc_version_status = '<span '.$green_text.'>WooCommerce version : '.$wc_version.' (OK)</span>';
            }else{
                $wc_version_status = '<span '.$red_text.'>Min recommended WooCommerce version : 2.5 (ERROR)</span>';
            }

            if (version_compare($tls_version, '1.2', '>=')) {
                $tls_version_status = '<span '.$green_text.'>TLS version : '.$tls_version.' (OK)</span>';
            }else{
                $tls_version_status = '<span '.$red_text.'>TLS version require : 1.2 (ERROR)</span> <a href="https://www.paypal-knowledge.com/infocenter/index?page=content&id=FAQ1914&expand=true&locale=en_US" target="_blank">Click here for info</a>';
            }
            
            if (version_compare($http_version, '1.1', '>=')) {
                $http_version_status = '<span '.$green_text.'>'.$_SERVER['SERVER_PROTOCOL'].' (OK)</span>';
            }else{
                $http_version_status = '<span '.$red_text.'>HTTP/1.1 require</span> <a href="https://www.paypal-knowledge.com/infocenter/index?page=content&id=FAQ1914&expand=true&locale=en_US" target="_blank">Click here for info</a>';
            }

            $html = '';
            $html .= '<ul class="wpneo_d_status_list">';
                $html .= '<li>'.$crowdfunding_version.'</li>';
                $html .= '<li>'.$php_version_status.'</li>';
                $html .= '<li>'.$wp_version_status.'</li>';
                $html .= '<li>'.$wc_version_status.'</li>';
                $html .= '<li>'.$tls_version_status.'</li>';
                $html .= '<li>'.$http_version_status.'</li>';
            $html .= '</ul>';
            echo $html;
        }


    }
}
WPNEO_Adaptive_Payment_Status_Dashboard::instance();