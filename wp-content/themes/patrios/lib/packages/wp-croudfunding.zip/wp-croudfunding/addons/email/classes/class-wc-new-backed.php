<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * A custom Expedited Order WooCommerce Email class
 *
 * @since 0.1
 * @extends \WC_Email
 */
class WP_Crowdfunding_New_Backed_Email extends WC_Email {

	protected $email_body;

	protected $sent_to_campaign_owner;
	protected $sent_to_backer;
	protected $email_template;
	/**
	 * Set email defaults
	 *
	 * @since 0.1
	 */
	public function __construct() {

		// set ID, this simply needs to be a unique name
		$this->id = 'wp_crowdfunding_new_backed';

		// this is the title in WooCommerce Email settings
		$this->title = 'WP CrowdFunding New Backed Notification';

		// this is the description in WooCommerce email settings
		$this->description = 'Expedited Backed Notification emails are sent when a customer places an order';

		// these are the default heading and subject lines that can be overridden using the settings
		$this->heading = 'WP Crowdfunding (A new backed has been placed)';
		$this->subject = 'WP Crowdfunding (A new backed has been placed)';

		$this->email_body = $this->get_option('body');

		$this->email_template = 'new-backed.php';
		// these define the locations of the templates that this email should use, we'll just use the new order template since this email is similar
		$this->template_html  = WPNEO_CROWDFUNDING_DIR_PATH.'wpneotemplate/woocommerce/basic/emails/'.$this->email_template;
		$this->template_plain = WPNEO_CROWDFUNDING_DIR_PATH.'wpneotemplate/woocommerce/basic/emails/'.$this->email_template;;

		// Triggers for this email
		add_action( 'woocommerce_order_status_pending_to_on-hold_notification', array( $this, 'trigger' ), 10, 2 );
		add_action( 'woocommerce_order_status_failed_to_on-hold_notification', array( $this, 'trigger' ), 10, 2 );

		// Call parent constructor to load any other defaults not explicity defined here
		parent::__construct();

		// this sets the recipient to the settings defined below in init_form_fields()
		//$this->recipient = $this->get_option( 'recipient' );
		$this->sent_to_campaign_owner = $this->get_option( 'sent_to_campaign_owner' );
		$this->sent_to_backer = $this->get_option( 'sent_to_backer' );

		// if none was entered, just use the WP admin email as a fallback
		/*if ( ! $this->recipient ){
			$this->recipient = get_option( 'admin_email' );
		}*/

	}


	/**
	 * Determine if the email should actually be sent and setup email merge variables
	 *
	 * @since 0.1
	 * @param int $order_id
	 */
	public function trigger( $order_id, $order = false ) {
		if ( ! $this->is_enabled() ) {
			return;
		}

		global $wpdb;

		if ( $order_id && ! is_a( $order, 'WC_Order' ) ) {
			$order = wc_get_order( $order_id );
		}

		$line_items     = $order->get_items('line_item');
		$ids            = array();
		foreach ($line_items as $item_id => $item) {
			$product_id = $wpdb->get_var("select meta_value from {$wpdb->prefix}woocommerce_order_itemmeta WHERE order_item_id = {$item_id} AND meta_key = '_product_id'");
			$ids[]      = $product_id;
		}
		$product        = wc_get_product($product_id);

		if ($product->is_type('crowdfunding') ) {

			$author         = get_userdata($product->post->post_author);
			$dislay_name    = $author->display_name;

			$total_amount   = get_woocommerce_currency_symbol() . $order->get_total();
			$campaign_title  = $product->post->post_title;
			$shortcode      = array('[user_name]', '[site_title]', '[total_amount]', '[campaign_title]');
			$replace_str    = array($dislay_name, get_option('blogname'), $total_amount, $campaign_title);


			$email_str      = str_replace($shortcode, $replace_str, $this->get_content());
			$subject        = str_replace($shortcode, $replace_str, $this->get_subject());


			if ($this->sent_to_campaign_owner){
				$this->setup_locale();
				$this->send( $author->user_email, $subject, $email_str, $this->get_headers(), $this->get_attachments() );
				$this->restore_locale();
			}

			if ($this->sent_to_backer){
				$backer_email_str      = str_replace($shortcode, $replace_str, $this->get_backer_content_html());
				$backer_subject        = str_replace($shortcode, $replace_str, $this->get_option('subject_for_backer'));

				$this->setup_locale();
				$this->send( $order->get_billing_email(), $backer_subject, $backer_email_str, $this->get_headers(), $this->get_attachments() );
				$this->restore_locale();
			}




		}

	}


	/**
	 * get_content_html function.
	 *
	 * @since 0.1
	 * @return string
	 */
	public function get_content_html() {
		$email_heading = $this->get_heading();
		$email_body = $this->email_body;

		$default_template = WPNEO_CROWDFUNDING_DIR_PATH.'wpneotemplate/woocommerce/basic/emails/'.$this->email_template;

		if (class_exists('Wpneo_Crowdfunding_Templating')){
			$cf_templating = new Wpneo_Crowdfunding_Templating();
			if ( file_exists($cf_templating->_theme_in_themes_path.'emails/'.$this->email_template) ){
				$default_template = $cf_templating->_theme_in_themes_path.'emails/'.$this->email_template;
			}else{
				$default_template = $cf_templating->_theme_in_plugin_path.'emails/'.$this->email_template;
			}
		}

		ob_start();
		include $default_template;
		return ob_get_clean();
	}


	public function get_backer_content_html() {
		$email_heading = $this->get_option('heading_for_backer');
		$email_body = $this->get_option('body_for_backer');

		$default_template = WPNEO_CROWDFUNDING_DIR_PATH.'wpneotemplate/woocommerce/basic/emails/'.$this->email_template;

		if (class_exists('Wpneo_Crowdfunding_Templating')){
			$cf_templating = new Wpneo_Crowdfunding_Templating();
			if ( file_exists($cf_templating->_theme_in_themes_path.'emails/'.$this->email_template) ){
				$default_template = $cf_templating->_theme_in_themes_path.'emails/'.$this->email_template;
			}else{
				$default_template = $cf_templating->_theme_in_plugin_path.'emails/'.$this->email_template;
			}
		}

		ob_start();
		include $default_template;
		return ob_get_clean();
	}

	/**
	 * get_content_plain function.
	 *
	 * @since 0.1
	 * @return string
	 */
	public function get_content_plain() {
		ob_start();
		$email_heading = $this->get_heading();
		$email_body = $this->email_body;
		require WPNEO_CROWDFUNDING_DIR_PATH.'wpneotemplate/woocommerce/basic/emails/'.$this->email_template;
		return ob_get_clean();
	}


	/**
	 * Initialize Settings Form Fields
	 *
	 * @since 2.0
	 */
	public function init_form_fields() {

		$this->form_fields = array(
			'enabled'    => array(
				'title'   => 'Enable/Disable',
				'type'    => 'checkbox',
				'label'   => 'Enable this email notification',
				'default' => 'yes'
			),

			'sent_to_campaign_owner'    => array(
				'title'   => 'Enable/Disable',
				'type'    => 'checkbox',
				'label'   => 'Notify to Campaign Owner',
				'default' => 'no'
			),

			'sent_to_backer'    => array(
				'title'   => 'Enable/Disable',
				'type'    => 'checkbox',
				'label'   => 'Notify to backer',
				'default' => 'no'
			),

		/*	'recipient'  => array(
				'title'       => 'Recipient(s)',
				'type'        => 'text',
				'description' => sprintf( 'Enter recipients (comma separated) for this email. Defaults to <code>%s</code>.', esc_attr( get_option( 'admin_email' ) ) ),
				'placeholder' => '',
				'default'     => ''
			),*/
			'subject'    => array(
				'title'       => 'Subject',
				'type'        => 'text',
				'description' => sprintf( 'This controls the email subject line. Leave blank to use the default subject: <code>%s</code>.', $this->subject ),
				'placeholder' => '',
				'default'     => ''
			),

			'subject_for_backer'    => array(
				'title'       => __('Subject For Backer', 'wp-crowdfunding'),
				'type'        => 'text',
				'description' => sprintf( 'This controls the backer notification email subject line. Leave blank to use the default subject: <code>%s</code>.', $this->subject ),
				'placeholder' => '',
				'default'     => __('Thank you for your donation', 'wp-crowdfunding')
			),
			'heading'    => array(
				'title'       => 'Email Heading',
				'type'        => 'textarea',
				'description' => sprintf( __( 'This controls the main heading contained within the email notification. Leave blank to use the default heading: <code>%s</code>.' ), $this->heading ),
				'placeholder' => '',
				'default'     => ''
			),
			'heading_for_backer'    => array(
				'title'       => __('Email Backer Heading', 'wp-crowdfunding'),
				'type'        => 'textarea',
				'description' => sprintf( __( 'This controls the main heading contained within the backer email notification. Leave blank to use the default heading: <code>%s</code>.' ), $this->heading ),
				'placeholder' => '',
				'default'     => ''
			),

			'body'    => array(
				'title'       => 'Email Body',
				'type'        => 'textarea',
				'description' => 'This controls the main email body contained within the email notification. Leave blank to keep it null',
				'placeholder' => '',
				'default'     => ''
			),

			'body_for_backer'    => array(
				'title'       => 'Email Body For backer',
				'type'        => 'textarea',
				'description' => 'This controls the main email body contained within the backer email notification. Leave blank to keep it null',
				'placeholder' => '',
				'default'     => ''
			),


			'email_type' => array(
				'title'         => __( 'Email type', 'woocommerce' ),
				'type'          => 'select',
				'description'   => __( 'Choose which format of email to send.', 'woocommerce' ),
				'default'       => 'html',
				'class'         => 'email_type wc-enhanced-select',
				'options'       => $this->get_email_type_options(),
				'desc_tip'      => true,
			),
		);
	}


} // end \WC_Expedited_Order_Email class
