jQuery(document).ready(function($) {
    $('.datepickers_1').datepicker({
        dateFormat: 'yy-mm-dd'
    });
    $('.datepickers_2').datepicker({
        dateFormat: 'yy-mm-dd'
    });
});