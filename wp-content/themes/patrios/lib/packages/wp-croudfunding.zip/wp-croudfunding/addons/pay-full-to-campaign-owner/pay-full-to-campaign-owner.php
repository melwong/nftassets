<?php
if ( ! defined('ABSPATH'))
	exit;
/**
 * Add a settings for enable disable ability
 *
 * @since WP Crowdfunding 20.21
 */
add_filter('wp_crowdfunding_wc_settings', 'full_to_campaign_owner_settings', 10, 1);
if ( ! function_exists('full_to_campaign_owner_settings')){
	function full_to_campaign_owner_settings($settings){
		//Seperator
		$settings[] = array(
			'type'      => 'seperator',
			'label'     => __('Pay full to Campaign Owner Settigns','wp-crowdfunding'),
			'desc'      => __('Enable or disable ability to Pay 100% fund to campaign owner Via PayPal standard 
			Payment','wp-crowdfunding'),
			'top_line'  => 'true',
		);

		// #Send 100% Payment to Campaign Owner
		$settings[] = array(
				'id'        => 'is_sent_full_payment_to_campaign_owner',
				'type'      => 'checkbox',
				'value'     => 'true',
				'label'     => __('Send 100% Payment to Campaign Owner (PayPal Standard Only)','wp-crowdfunding'),
				'desc'      => __('Enable/Disable','wp-crowdfunding'),
			);

		return $settings;
	}
}

/**
 * Save Settings
 *
 * @since WP Crowdfunding 20.21
 */
add_action('admin_init', 'save_pay_full_campaign_owner_settings');
if ( ! function_exists('save_pay_full_campaign_owner_settings')){
	function save_pay_full_campaign_owner_settings(){
		if ( isset($_POST['is_sent_full_payment_to_campaign_owner'])){
			$is_sent_full_payment_to_campaign_owner = sanitize_text_field(wpneo_post('is_sent_full_payment_to_campaign_owner'));
			wpneo_crowdfunding_update_option_checkbox('is_sent_full_payment_to_campaign_owner', $is_sent_full_payment_to_campaign_owner);
		}
	}
}

/**
 * Since Wp Crowdfunding 20.21
 */
add_filter('woocommerce_paypal_args', 'pay_full_payment_to_campaign_owner', 10, 2);
function pay_full_payment_to_campaign_owner($paypal_param, $order){
	if (empty($paypal_param))
		return;

	$order_id = $order->get_id();

	//Checking is order for wp crowdfunding
	if ( ! get_post_meta($order_id, 'is_crowdfunding_order', true))
		return $paypal_param;

	$is_sent_full_payment_to_campaign_owner = get_option('is_sent_full_payment_to_campaign_owner');
	if ($is_sent_full_payment_to_campaign_owner !== 'true')
		return $paypal_param;


	$is_crowdfunding_product_exists = false;
	foreach ($order->get_items() as $item) {
		$product = wc_get_product($item['product_id']);
		if($product->get_type() == 'crowdfunding'){
			$is_crowdfunding_product_exists = true;
		}
	}

	if ( ! $is_crowdfunding_product_exists){
		return $paypal_param;
	}

	$get_the_receiver_email = get_user_meta(get_current_user_id(), 'adaptive_paypal_receiver_email', true);
	if ( ! $get_the_receiver_email){
		return $paypal_param;
	}
	$paypal_param['business'] = $get_the_receiver_email;

	return $paypal_param;
}
