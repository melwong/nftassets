<?php

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * A custom Expedited Order WooCommerce Email class
 *
 * @since 0.1
 * @extends \WC_Email
 */
class WP_Crowdfunding_New_User_Email extends WC_Email {

	protected $email_body;

	protected $sent_to_admin;
	protected $sent_to_user;
	/**
	 * Set email defaults
	 *
	 * @since 0.1
	 */
	public function __construct() {

		// set ID, this simply needs to be a unique name
		$this->id = 'wp_crowdfunding_new_user';

		// this is the title in WooCommerce Email settings
		$this->title = 'WP CrowdFunding New User';

		// this is the description in WooCommerce email settings
		$this->description = 'Expedited Order Notification emails are sent when a customer places an order with 3-day or next day shipping';

		// these are the default heading and subject lines that can be overridden using the settings
		$this->heading = 'WP Crowdfunding New User Registration [user_name]';
		$this->subject = 'WP Crowdfunding New User Registration';

		$this->email_body = $this->get_option('body');

		// these define the locations of the templates that this email should use, we'll just use the new order template since this email is similar
		$this->template_html  = WPNEO_CROWDFUNDING_DIR_PATH.'wpneotemplate/woocommerce/basic/emails/new-user-registration.php';
		$this->template_plain = WPNEO_CROWDFUNDING_DIR_PATH.'wpneotemplate/woocommerce/basic/emails/new-user-registration.php';;

		// Trigger on new paid orders
		add_action( 'wpneo_crowdfunding_after_user_registration', array( $this, 'trigger' ) );

		// Call parent constructor to load any other defaults not explicity defined here
		parent::__construct();

		// this sets the recipient to the settings defined below in init_form_fields()
		$this->recipient = $this->get_option( 'recipient' );
		$this->sent_to_admin = $this->get_option( 'is_email_to_admin' );
		$this->sent_to_user = $this->get_option( 'is_email_to_user' );

		// if none was entered, just use the WP admin email as a fallback
		if ( ! $this->recipient ){
			$this->recipient = get_option( 'admin_email' );
		}

	}


	/**
	 * Determine if the email should actually be sent and setup email merge variables
	 *
	 * @since 0.1
	 * @param int $order_id
	 */
	public function trigger($user_id =  null) {
		$user = get_userdata($user_id);
		// replace variables in the subject/headings
		$this->find[] = '[user_name]';
		$this->replace[] = $user->user_nicename;

		if ( ! $this->is_enabled() )
			return;

		$author         = get_userdata( $user_id );
		$dislay_name    = $author->display_name;

		$shortcode      = array( '[user_name]' );
		$replace_str    = array( $dislay_name );

		if ($this->sent_to_admin){
			//Send the email now
			$this->send( $this->recipient, $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		}


		/**
		 * Send greetings to newly created user
		 */
		if ($this->sent_to_user){
			$user_email_str      = str_replace($shortcode, $replace_str, $this->get_content_html_for_user());
			$user_subject        = str_replace($shortcode, $replace_str, $this->get_option('subject_user'));

			$this->setup_locale();
			$this->send( $author->user_email, $user_subject, $user_email_str, $this->get_headers(), $this->get_attachments() );
			$this->restore_locale();
		}


	}


	/**
	 * get_content_html function.
	 *
	 * @since 0.1
	 * @return string
	 */
	public function get_content_html() {
		$email_heading = $this->get_heading();
		$email_body = $this->email_body;

		$default_template = WPNEO_CROWDFUNDING_DIR_PATH.'wpneotemplate/woocommerce/basic/emails/new-user-registration.php';

		if (class_exists('Wpneo_Crowdfunding_Templating')){
			$cf_templating = new Wpneo_Crowdfunding_Templating();
			if ( file_exists($cf_templating->_theme_in_themes_path.'emails/new-user-registration.php') ){
				$default_template = $cf_templating->_theme_in_themes_path.'emails/new-user-registration.php';
			}else{
				$default_template = $cf_templating->_theme_in_plugin_path.'emails/new-user-registration.php';
			}
		}

		ob_start();
		include $default_template;
		return ob_get_clean();
	}


	public function get_content_html_for_user() {
		$email_heading = $this->get_option('heading_user');
		$email_body = $this->get_option('body_user');

		$default_template = WPNEO_CROWDFUNDING_DIR_PATH.'wpneotemplate/woocommerce/basic/emails/new-user-registration.php';

		if (class_exists('Wpneo_Crowdfunding_Templating')){
			$cf_templating = new Wpneo_Crowdfunding_Templating();
			if ( file_exists($cf_templating->_theme_in_themes_path.'emails/new-user-registration.php') ){
				$default_template = $cf_templating->_theme_in_themes_path.'emails/new-user-registration.php';
			}else{
				$default_template = $cf_templating->_theme_in_plugin_path.'emails/new-user-registration.php';
			}
		}

		ob_start();
		include $default_template;
		return ob_get_clean();
	}


	/**
	 * get_content_plain function.
	 *
	 * @since 0.1
	 * @return string
	 */
	public function get_content_plain() {
		ob_start();
		$email_heading = $this->get_heading();
		$email_body = $this->email_body;
		require WPNEO_CROWDFUNDING_DIR_PATH.'wpneotemplate/woocommerce/basic/emails/new-user-registration.php';
		return ob_get_clean();
	}


	/**
	 * Initialize Settings Form Fields
	 *
	 * @since 2.0
	 */
	public function init_form_fields() {

		$this->form_fields = array(
			'enabled'    => array(
				'title'   => 'Enable/Disable',
				'type'    => 'checkbox',
				'label'   => 'Enable this email notification',
				'default' => 'yes'
			),

			'is_email_to_admin'    => array(
				'title'   => 'Enable/Disable',
				'type'    => 'checkbox',
				'label'   => 'Send Email to Admin',
				'default' => 'no'
			),
			'is_email_to_user'    => array(
				'title'   => 'Enable/Disable',
				'type'    => 'checkbox',
				'label'   => 'Send Email Greetings To User',
				'default' => 'no'
			),



			'recipient'  => array(
				'title'       => 'Recipient(s)',
				'type'        => 'text',
				'description' => sprintf( 'Enter recipients (comma separated) for this email. Defaults to <code>%s</code>.', esc_attr( get_option( 'admin_email' ) ) ),
				'placeholder' => '',
				'default'     => ''
			),
			'subject'    => array(
				'title'       => 'Subject',
				'type'        => 'text',
				'description' => sprintf( 'This controls the email subject line. Leave blank to use the default subject: <code>%s</code>.', $this->subject ),
				'placeholder' => '',
				'default'     => ''
			),
			'heading'    => array(
				'title'       => 'Email Heading',
				'type'        => 'textarea',
				'description' => sprintf( __( 'This controls the main heading contained within the email notification. Leave blank to use the default heading: <code>%s</code>.' ), $this->heading ),
				'placeholder' => '',
				'default'     => ''
			),
			'body'    => array(
				'title'       => 'Email Body',
				'type'        => 'textarea',
				'description' => 'This controls the main email body contained within the email notification. Leave blank to keep it null',
				'placeholder' => '',
				'default'     => ''
			),



			'subject_user'    => array(
				'title'       => __('Subject for User', 'wp-crowdfunding'),
				'type'        => 'text',
				'description' => sprintf( 'This controls the email subject line. Leave blank to use the default subject: <code>%s</code>.', $this->subject ),
				'placeholder' => '',
				'default'     => ''
			),
			'heading_user'    => array(
				'title'       => __('Email Heading for User', 'wp-crowdfunding'),
				'type'        => 'textarea',
				'description' => sprintf( __( 'This controls the main heading contained within the email notification. Leave blank to use the default heading: <code>%s</code>.' ), $this->heading ),
				'placeholder' => '',
				'default'     => ''
			),
			'body_user'    => array(
				'title'       => __('Email Body for User', 'wp-crowdfunding'),
				'type'        => 'textarea',
				'description' => 'This controls the main email body contained within the email notification. Leave blank to keep it null',
				'placeholder' => '',
				'default'     => ''
			),



			'email_type' => array(
				'title'         => __( 'Email type', 'woocommerce' ),
				'type'          => 'select',
				'description'   => __( 'Choose which format of email to send.', 'woocommerce' ),
				'default'       => 'html',
				'class'         => 'email_type wc-enhanced-select',
				'options'       => $this->get_email_type_options(),
				'desc_tip'      => true,
			),

		);
	}


} // end \WC_Expedited_Order_Email class
