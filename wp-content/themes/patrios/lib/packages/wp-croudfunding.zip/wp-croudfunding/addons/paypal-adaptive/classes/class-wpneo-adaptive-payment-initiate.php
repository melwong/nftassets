<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if (! class_exists('WPNEO_Adaptive_Payment_Initiate')) {

    class WPNEO_Adaptive_Payment_Initiate{

        protected static $_instance;

        public static function instance(){
            if (is_null(self::$_instance)) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        public function __construct(){
            //Init hook for wpneo_crowdfunding_check_ipn()
            add_action('init', array($this, 'wpneo_crowdfunding_check_ipn'));

            // Remove the Other Payment Gatway if the adaptive is active
            $adaptive_payment_settings = (object) get_option('woocommerce_paypal_adaptive_payment_settings');

            if ( ! empty($adaptive_payment_settings->enabled)){
                if ($adaptive_payment_settings->enabled == 'yes'){
                    add_filter( 'woocommerce_available_payment_gateways', array($this, 'wpneo_crowdfunding_filter_gateways'), 1);
                }
            }

            add_action('wpneo_crowdfunding_dashboard_after_dashboard_form', array($this, 'generate_paypal_adaptive_receiver_email'),12);
            add_action('wpneo_crowdfunding_after_save_dashboard', array($this, 'wpneo_crowdfunding_after_save_profile_action'));
        }

        //IPN handler function
        function wpneo_crowdfunding_check_ipn() {
            if (isset($_GET['ipn'])) {
                $adaptive_payment_settings = (object) get_option('woocommerce_paypal_adaptive_payment_settings');

                $paypal_ipn_url = '';
                if ( $adaptive_payment_settings->sandbox == 'yes') {
                    $paypal_ipn_url = "https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_notify-validate";
                } else {
                    $paypal_ipn_url = "https://www.paypal.com/cgi-bin/webscr?cmd=_notify-validate";
                }

                $ipn_post = !empty($_POST) ? $_POST : false;
                if ($ipn_post) {
                    header('HTTP/1.1 200 OK');
                    $self_custom = $_GET['self_custom'];
                    $received_post = file_get_contents("php://input"); // adaptive payment ipn message is different from normal paypal so we handle like this

                    $posted_response = wp_remote_request($paypal_ipn_url, array('method' => 'POST', 'timeout' => 20, 'httpversion' => '1.1', 'body' => $received_post));

                    $received_raw_post_array = explode('&', $received_post);
                    $post_maded = array(); // making post from raw
                    foreach ($received_raw_post_array as $keyval) {
                        $keyval = explode('=', $keyval);
                        if (count($keyval) == 2)
                            $post_maded[urldecode($keyval[0])] = urldecode($keyval[1]);
                    }

                    if (strcmp($posted_response['body'], "VERIFIED") == 0) {
                        $received_order_id = $self_custom;
                        //$payment_status = $post_maded['transaction[0].status']; // first user status
                        $payment_status = $post_maded['status']; // first user status
                        if ($payment_status == 'COMPLETED') {

                            $order = new WC_Order($received_order_id);
                            if ($order->get_id()) { // if order exist
                                $total = 0;
                                if ( $adaptive_payment_settings->payment_mode == 'parallel' ) {
                                    for ($i = 0; $i <= 2; $i++) {
                                        if (isset($post_maded["transaction[$i].amount"])) {
                                            $total = $total + preg_replace("/[^0-9,.]/", "", $post_maded["transaction[$i].amount"]);
                                        }
                                    }
                                } else {
                                    $total = preg_replace("/[^0-9,.]/", "", $post_maded["transaction[0].amount"]);
                                }
                                if ($total == $order->order_total) { //checking order total with payment as suggested by paypal ipn documentaion to avoid fraud pay
                                    $order->payment_complete();
                                }
                                update_post_meta($order->get_id(), 'Transaction ID', $post_maded['transaction[0].id']); // adding transaction ID to order for future reference
                            }
                        }
                    }
                }
            }
        }

        function wpneo_crowdfunding_filter_gateways($gateways){
            global $woocommerce;
            foreach ($woocommerce->cart->cart_contents as $key => $values) {
                if (isset($values['product_id'])) {
                    $_product = wc_get_product($values['product_id']);
                    if ($_product->is_type('crowdfunding')) {
                        if (is_array($gateways)) {
                            foreach ($gateways as $key => $value) {
                                if ($key != 'paypal_adaptive_payment') {
                                    unset($gateways[$key]);
                                }
                            }
                        }
                    }else{
                        unset($gateways['paypal_adaptive_payment']);
                    }
                }
            }
            return $gateways;
        }

        function generate_paypal_adaptive_receiver_email(){
            $data = get_user_meta(get_current_user_id());

            // Paypal receiver email
            $html = '';
            $html .= '<div class="wpneo-single">';
                $html .= '<div class="wpneo-name float-left">';
                    $html .= '<p>'.__( "Paypal Receiver Email:" , "wp-crowdfunding" ).'</p>';
                $html .= '</div>';
                $html .= '<div class="wpneo-fields float-right">';
                    $value = ''; if(isset($data['adaptive_paypal_receiver_email'][0])){ $value = esc_textarea($data['adaptive_paypal_receiver_email'][0]); }
                    $html .= '<input type="text" name="adaptive_paypal_receiver_email" value="'.$value.'" disabled>';
                $html .= '</div>';
            $html .= '</div>';

            echo $html;
        }

        function wpneo_crowdfunding_after_save_profile_action(){
            $user_id = get_current_user_id();
            $adaptive_paypal_receiver_email = sanitize_text_field(wpneo_post('adaptive_paypal_receiver_email'));
            update_user_meta($user_id,'adaptive_paypal_receiver_email',$adaptive_paypal_receiver_email);
        }


    }
}
WPNEO_Adaptive_Payment_Initiate::instance();