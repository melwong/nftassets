<?php
/**
 * Send email after various event
 *
 * @package : mail
 * @plugin wp-crowdfunding
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists('Wpneo_Crowdfunding_Email')) {
    class Wpneo_Crowdfunding_Email
    {
        /**
         * @var null
         *
         * Instance of this class
         */
        protected static $_instance = null;

        /**
         * @return null|Wpneo_Crowdfunding
         */
        public static function instance() {
            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        /**
         * Wpneo_Crowdfunding_Email constructor.
         */
        public function __construct(){
	        //Email classes
	        add_filter( 'woocommerce_email_classes', array($this, 'add_email_classes') );
        }


	    /**
	     * @param $email_classes
	     *
	     * @return mixed
	     *
	     * Add email classes to WC Email Settings
	     *
	     * @since v.10.20
	     */
        public function add_email_classes($email_classes){
	        // include our custom email class
	        require_once( WPNEO_CROWDFUNDING_DIR_PATH.'addons/email/classes/class-wc-new-user-email.php' );
	        require_once( WPNEO_CROWDFUNDING_DIR_PATH.'addons/email/classes/class-wc-new-backed.php' );
	        require_once( WPNEO_CROWDFUNDING_DIR_PATH.'addons/email/classes/class-wc-campaign-accept.php' );
	        require_once( WPNEO_CROWDFUNDING_DIR_PATH.'addons/email/classes/class-wc-submit-campaign.php' );

	        // add the email class to the list of email classes that WooCommerce loads
	        $email_classes['WP_Crowdfunding_New_User_Email'] = new WP_Crowdfunding_New_User_Email();
	        $email_classes['WP_Crowdfunding_New_Backed_Email'] = new WP_Crowdfunding_New_Backed_Email();
	        $email_classes['WP_Crowdfunding_Campaign_Accept'] = new WP_Crowdfunding_Campaign_Accept();
	        $email_classes['WP_Crowdfunding_Submit_Campaign'] = new WP_Crowdfunding_Submit_Campaign();

	        return $email_classes;
        }

    }
}
Wpneo_Crowdfunding_Email::instance();

add_action('pre_post_update', 'wpneo_crowdfunding_load_wc_email_class_instance', 10);

if ( ! function_exists('wpneo_crowdfunding_load_wc_email_class_instance')){
	function wpneo_crowdfunding_load_wc_email_class_instance(){
		WC()->mailer();
	}
}