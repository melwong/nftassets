<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<!--div class="wpneo-listing-buttons">
    <a href="< ?php echo get_permalink(); ? >" class="btn-details">< ?php echo __('Campaign Details', 'wp-crowdfunding'); ? ></a>
</div-->