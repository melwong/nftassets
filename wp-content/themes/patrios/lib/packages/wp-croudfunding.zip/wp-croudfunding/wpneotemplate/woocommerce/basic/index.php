<?php
/**
 * Theme Name: WPNEO Crowdfunding Basic
 * version: 1.0.0
 * Copyright: WPNEO
 */