<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<div class="woocommerce">
    <p class="woocommerce-info"><?php _e( 'No campaigns found here.', 'wp-crowdfunding' ); ?></p>
</div>
