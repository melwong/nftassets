<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<h4><a href="<?php  echo get_permalink(); ?> "><?php echo get_the_title(); ?></a></h4>
