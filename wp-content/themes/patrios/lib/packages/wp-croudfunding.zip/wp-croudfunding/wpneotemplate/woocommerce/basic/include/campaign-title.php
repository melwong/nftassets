<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
?>
<h2 class="wpneo-campaign-title"><?php the_title(); ?></h2>